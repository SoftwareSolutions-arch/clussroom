import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-sessions',
  templateUrl: './live-sessions.component.html',
  styleUrls: ['./live-sessions.component.css']
})
export class LiveSessionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
