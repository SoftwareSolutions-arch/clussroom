import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learners',
  templateUrl: './learners.component.html',
  styleUrls: ['./learners.component.css']
})
export class LearnersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
